import os, subprocess, time, signal
import numpy as np
import gym
from gym import error, spaces
from gym import utils
from gym.utils import seeding
import math
import random
import logging

import pyfastsim as fs

logger = logging.getLogger(__name__)

default_env = "assets/LS_maze_hard.xml"
#default_env = "assets/example.xml"

sticky_walls = False # default is True in libfastsim... but false in the fastsim sferes2 module -> stick (haha) with that


def sqdist(x,y):
	return (x[0]-y[0])**2+(x[1]-y[1])**2

def dist(x,y):
	return math.sqrt(sqdist(x,y))

class SimpleNavEnv(gym.Env):
	def __init__(self,xml_env=default_env, still_limit=None, reward_kind="continuous"):
		# XML files typically contain relative names (for map) wrt their own path. Make that work
		xml_dir, xml_file = os.path.split(xml_env)
		if(xml_dir == ""):
			xml_dir = "./"
		oldcwd = os.getcwd()
		os.chdir(xml_dir)
		settings = fs.Settings(xml_file)
		os.chdir(oldcwd)
		
		self.reward_kind = reward_kind

		self.display = None
		self.map = settings.map()
		self.robot = settings.robot()

		self.still_limit=still_limit
		self.still=0

		self.maxVel = 4 # Same as in the C++ sferes2 experiment
		
		lasers = self.robot.get_lasers()
		n_lasers = len(lasers)
		self.maxSensorRange = lasers[0].get_range() # Assume at least 1 laser ranger
		
		self.initPos = self.get_robot_pos()
		self.roldpos = None
		
		self.goal = self.map.get_goals()[0] # Assume 1 goal
		self.goalPos=[self.goal.get_x(),self.goal.get_y()]
		self.goalRadius = self.goal.get_diam()/2.
		
		self.observation_space = spaces.Box(low=np.array([0.]*n_lasers + [0.]*2), high=np.array([self.maxSensorRange]*n_lasers + [1.]*2), dtype=np.float32)
		self.action_space = spaces.Box(low=-self.maxVel, high=self.maxVel, shape=(2,), dtype=np.float32)

	def enable_display(self):
		if not self.display:
			self.display = fs.Display(self.map, self.robot)
			self.display.update()

	def disable_display(self):
		if self.display:
			del self.display
			self.display = None

	def get_robot_pos(self):
		pos = self.robot.get_pos()
		return [pos.x(), pos.y(), pos.theta()]

	def get_laserranges(self):
		out = list()
		for l in self.robot.get_lasers():
			r = l.get_dist()
			if r < 0:
				out.append(self.maxSensorRange)
			else:
				out.append(np.clip(r,0.,self.maxSensorRange))
		return out

	def get_bumpers(self):
		return [float(self.robot.get_left_bumper()), float(self.robot.get_right_bumper())]


	def get_all_sensors(self):
		return self.get_laserranges() + self.get_bumpers()

	def step(self, action):
		# Action is: [leftWheelVel, rightWheelVel]
		[v1, v2] = action
		
		self.robot.move(np.clip(v1,-self.maxVel,self.maxVel),np.clip(v2,-self.maxVel,self.maxVel), self.map, sticky_walls)

		sensors = self.get_all_sensors()

		bin_reward = self._get_binary_reward()

		cont_reward = self._get_continuous_reward()

		p = self.get_robot_pos()
		
		if(self.roldpos is not None) and (sqdist(p,self.roldpos)<0.001**2):
			self.still=self.still+1
		else:
			self.still=0
		self.roldpos=p
		if (self.still_limit is not None):
			episode_over = self.still>=self.still_limit
		else:
			episode_over = False

		if(self.reward_kind=="binary"):
			reward=bin_reward
		elif(self.reward_kind=="continuous"):
			reward=cont_reward
		elif(self.reward_kind=="collisions"):
			reward=-self.robot.get_collision()

		return sensors, reward, episode_over, {"exit_reached":bin_reward,
						       "dist_obj":cont_reward, 
						       "robot_pos":p, 
						       "collision": self.robot.get_collision()}


	def _get_binary_reward(self):
		""" Reward is given when close enough to the goal. """
		p = self.get_robot_pos()
		if (dist(p,self.goalPos)<=self.goalRadius):
			return 1.
		else:
			return 0.

	def _get_continuous_reward(self):
		""" The reward is the opposite of the distance to the goal (to maximize) """
		dist_obj = dist(self.get_robot_pos(), self.goalPos)
		return -dist_obj

	def reset(self):
		p = fs.Posture(*self.initPos)
		self.robot.set_pos(p)
		self.step([0,0])
		self.roldpos=self.get_robot_pos()
		self.still=0
		return self.get_all_sensors()

	def render(self, mode='human', close=False):
		if self.display:
			self.display.update()
		pass

	def close(self):
		self.disable_display()
		del self.robot
		del self.map
		pass
